import json
import boto3
import os

ecs = boto3.client('ecs')
ec2 = boto3.client('ec2')
route53 = boto3.client('route53')

CLUSTER_NAME = os.environ['CLUSTER_NAME']
SERVICE_NAME = os.environ['SERVICE_NAME']
ZONE_ID = os.environ['ZONE_ID']
RECORD_NAME = os.environ['RECORD_NAME']

def lambda_handler(event, context):
    try:
        task_arn = event.get('detail', {}).get('taskArn')
        
        if not task_arn:
            list_response = ecs.list_tasks(
                cluster=CLUSTER_NAME,
                serviceName=SERVICE_NAME
            )
            if not list_response['taskArns']:
                print("No tasks found")
                return {'statusCode': 200, 'body': 'No tasks found'}
            task_arn = list_response['taskArns'][0]
        
        describe_response = ecs.describe_tasks(
            cluster=CLUSTER_NAME,
            tasks=[task_arn]
        )
        
        if not describe_response['tasks']:
            print("Task not found")
            return {'statusCode': 200, 'body': 'Task not found'}
        
        task = describe_response['tasks'][0]
        
        if task['lastStatus'] != 'RUNNING':
            print(f"Task not running: {task['lastStatus']}")
            return {'statusCode': 200, 'body': f"Task status: {task['lastStatus']}"}
        
        attachment = next(
            (a for a in task.get('attachments', []) if a['type'] == 'ElasticNetworkInterface'),
            None
        )
        
        if not attachment:
            print("No network interface found")
            return {'statusCode': 200, 'body': 'No network interface found'}
        
        network_interface_id = next(
            (d['value'] for d in attachment['details'] if d['name'] == 'networkInterfaceId'),
            None
        )
        
        if not network_interface_id:
            print("Network interface ID not found")
            return {'statusCode': 200, 'body': 'Network interface ID not found'}
        
        ni_response = ec2.describe_network_interfaces(
            NetworkInterfaceIds=[network_interface_id]
        )
        
        if not ni_response['NetworkInterfaces']:
            print("Network interface not found")
            return {'statusCode': 200, 'body': 'Network interface not found'}
        
        public_ip = ni_response['NetworkInterfaces'][0].get('Association', {}).get('PublicIp')
        
        if not public_ip:
            print("No public IP found")
            return {'statusCode': 200, 'body': 'No public IP found'}
        
        print(f"Updating DNS record {RECORD_NAME} to {public_ip}")
        
        route53.change_resource_record_sets(
            HostedZoneId=ZONE_ID,
            ChangeBatch={
                'Changes': [{
                    'Action': 'UPSERT',
                    'ResourceRecordSet': {
                        'Name': RECORD_NAME,
                        'Type': 'A',
                        'TTL': 60,
                        'ResourceRecords': [{'Value': public_ip}]
                    }
                }]
            }
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'DNS updated to {public_ip}',
                'ip': public_ip
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
